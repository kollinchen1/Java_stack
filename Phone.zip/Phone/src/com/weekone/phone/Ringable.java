package com.weekone.phone;

public interface Ringable {
	String ring();
	String unlock();
}
