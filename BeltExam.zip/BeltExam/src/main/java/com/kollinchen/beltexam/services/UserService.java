package com.kollinchen.beltexam.services;

import org.mindrot.jbcrypt.BCrypt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kollinchen.beltexam.models.User;
import com.kollinchen.beltexam.models.UserCourse;
import com.kollinchen.beltexam.repositories.UserCourseRepository;
import com.kollinchen.beltexam.repositories.UserRepository;

@Service
public class UserService {
	
	@Autowired
	private UserRepository userRepo;
	
	@Autowired
	private UserCourseRepository userCourseRepo;
	
	// -------------------- CRUD USERS ---------------------------//
	// register user and hash their password
    public User registerUser(User user) {
    	// TAKING THE PLAIN TEXT PASSWORD AND TURNING INTO HASHED VERSION
        String hashed = BCrypt.hashpw(user.getPassword(), BCrypt.gensalt());
        user.setPassword(hashed);
        return userRepo.save(user);
    }
    
    // find user by email
    public User findByEmail(String email) {
        return userRepo.findByEmail(email);
    }
    
    // find user by id
    public User findUserById(Long id) {
    	return userRepo.findById(id).orElse(null);
    }
    
    // authenticate user
    public boolean authenticateUser(String email, String password) {
        // first find the user by email
        User user = userRepo.findByEmail(email);
        // if we can't find it by email, return false
        if(user == null) {
            return false;
        } else {
            // if the passwords match, return true, else, return false
            if(BCrypt.checkpw(password, user.getPassword())) {
                return true;
            } else {
                return false;
            }
        }
    }
 // -------------------- CRUD USER GROUP -----------------------------//
 	public UserCourse saveUserGroup(UserCourse userCourse) {
 		return userCourseRepo.save(userCourse);
 	}

	
}
