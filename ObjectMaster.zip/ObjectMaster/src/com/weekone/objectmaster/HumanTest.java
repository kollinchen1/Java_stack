package com.weekone.objectmaster;

public class HumanTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Human h1 = new Human();
		Human h2 = new Human();
		h1.attack(h2);
		h2.attack(h1);
		h2.attack(h1);
		h2.attack(h1);
		System.out.println(h1.getHealth());
		System.out.println(h2.getHealth());
		
	}

}
