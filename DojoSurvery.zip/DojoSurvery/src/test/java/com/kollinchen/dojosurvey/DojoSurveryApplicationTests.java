package com.kollinchen.dojosurvey;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DojoSurveryApplicationTests {

	@Test
	void contextLoads() {
	}

}
