package com.weekone.pokemon;

public class PokemonTest {

	public static void main(String[] args) {
		Pokemon p1 = new Pokemon("char",100,"fire");
		Pokemon p2 = new Pokemon("bul",100,"water");
		p1.attackPokemon(p2);
		System.out.println(p1.getHealth());
		System.out.println(p2.getHealth());
		Pokedex po = new Pokedex();
		po.listPokemon();
	}

}
