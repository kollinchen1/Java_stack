package com.weekone.objectmaster;

public class HumanTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Human h1 = new Human();
		Human h2 = new Human();
//		h1.attack(h2);
//		h2.attack(h1);
//		h2.attack(h1);
//		h2.attack(h1);
//		System.out.println(h1.getHealth());
//		System.out.println(h2.getHealth());
		Ninja n1 = new Ninja();
		Ninja n2 = new Ninja();
		Wizard w1 = new Wizard();
		Wizard w2 = new Wizard();
		Samurai s1 = new Samurai();
		Samurai s2 = new Samurai();
		Samurai s3 = new Samurai();
		System.out.println(Samurai.totalSam());
	}

}
