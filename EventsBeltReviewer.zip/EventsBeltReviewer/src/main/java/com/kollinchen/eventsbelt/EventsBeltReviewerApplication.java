package com.kollinchen.eventsbelt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventsBeltReviewerApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventsBeltReviewerApplication.class, args);
	}

}
